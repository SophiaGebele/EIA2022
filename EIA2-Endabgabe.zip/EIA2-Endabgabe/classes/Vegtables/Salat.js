var Endabgabe;
(function (Endabgabe) {
    class salad extends Endabgabe.Vegtables {
        status = Endabgabe.STATUS.NOTHING;
        allImages = [, Endabgabe.Assets.plantingSeed, Endabgabe.Assets.growing, Endabgabe.Assets.saladPicture];
    }
    Endabgabe.salad = salad;
})(Endabgabe || (Endabgabe = {}));
//# sourceMappingURL=Salat.js.map