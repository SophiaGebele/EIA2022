namespace Endabgabe{
    export class salad extends Vegtables{
        status:STATUS=STATUS.NOTHING;
        protected allImages: HTMLImageElement[] = [ ,Assets.plantingSeed,Assets.growing, Assets.saladPicture];
    }
}