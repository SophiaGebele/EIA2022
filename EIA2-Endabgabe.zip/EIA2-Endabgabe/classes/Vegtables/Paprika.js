var Endabgabe;
(function (Endabgabe) {
    class paprika extends Endabgabe.Vegtables {
        status = Endabgabe.STATUS.NOTHING;
        allImages = [, Endabgabe.Assets.plantingSeed, Endabgabe.Assets.growing, Endabgabe.Assets.paprikaPicture];
    }
    Endabgabe.paprika = paprika;
})(Endabgabe || (Endabgabe = {}));
//# sourceMappingURL=Paprika.js.map