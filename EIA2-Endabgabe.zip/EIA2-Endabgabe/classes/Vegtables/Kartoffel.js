var Endabgabe;
(function (Endabgabe) {
    class Potato extends Endabgabe.Vegtables {
        status = Endabgabe.STATUS.NOTHING;
        allImages = [, Endabgabe.Assets.plantingSeed, Endabgabe.Assets.growing, Endabgabe.Assets.potatoPicture];
    }
    Endabgabe.Potato = Potato;
})(Endabgabe || (Endabgabe = {}));
//# sourceMappingURL=Kartoffel.js.map