var Endabgabe;
(function (Endabgabe) {
    class carrot extends Endabgabe.Vegtables {
        status = Endabgabe.STATUS.NOTHING;
        allImages = [, Endabgabe.Assets.plantingSeed, Endabgabe.Assets.growing, Endabgabe.Assets.carrotPicture];
    }
    Endabgabe.carrot = carrot;
})(Endabgabe || (Endabgabe = {}));
//# sourceMappingURL=Karotte.js.map