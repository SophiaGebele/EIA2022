var Endabgabe;
(function (Endabgabe) {
    class Cucumber extends Endabgabe.Vegtables {
        allImages = [, Endabgabe.Assets.plantingSeed, Endabgabe.Assets.growing, Endabgabe.Assets.cucmberPicture];
    }
    Endabgabe.Cucumber = Cucumber;
})(Endabgabe || (Endabgabe = {}));
//# sourceMappingURL=Gurke.js.map