namespace Endabgabe{
    
    export class Cucumber extends Vegtables{
        
        protected allImages: HTMLImageElement[] = [ ,Assets.plantingSeed,Assets.growing, Assets.cucmberPicture];

    }


}
