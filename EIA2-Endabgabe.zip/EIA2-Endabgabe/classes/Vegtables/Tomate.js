var Endabgabe;
(function (Endabgabe) {
    class tomato extends Endabgabe.Vegtables {
        status = Endabgabe.STATUS.NOTHING;
        allImages = [, Endabgabe.Assets.plantingSeed, Endabgabe.Assets.growing, Endabgabe.Assets.tomatoPicture];
    }
    Endabgabe.tomato = tomato;
})(Endabgabe || (Endabgabe = {}));
//# sourceMappingURL=Tomate.js.map