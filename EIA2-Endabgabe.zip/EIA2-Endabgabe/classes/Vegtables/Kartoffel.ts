namespace Endabgabe{
    export class Potato extends Vegtables{
        status:STATUS=STATUS.NOTHING;
        protected allImages: HTMLImageElement[] = [ ,Assets.plantingSeed,Assets.growing, Assets.potatoPicture];
    }
}