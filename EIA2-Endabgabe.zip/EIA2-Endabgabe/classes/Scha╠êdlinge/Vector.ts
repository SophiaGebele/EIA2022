namespace Endabgabe{
    export class Vector{
        positionX:number;
        positionY:number;
        
        constructor(_positionX: number, _positionY: number) {
            this.positionX = _positionX;
            this.positionY = _positionY;
        }
    }
}